package game_package;


public enum ID {

	Player(),
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	EnemyBoss(),
	Apples(),
	Trail();
}

