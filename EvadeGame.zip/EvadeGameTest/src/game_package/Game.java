package game_package;

//Some new concepts I implemented in my game was extended a class to a window/canvas, generating a enemy AI, converting key inputs into movement, and more
//I used arrays to store my GameObjects in a LinkedList format as seen on Handler.java
//I used if else statement throughout most of the game such as when determining when certain animations would be queued
//Procedures and functions were implemented in various parts of the game
//I used for loops to maintain certain spawn aspects as well as to loop some general functions

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.Random;
import java.util.Scanner;

//Extends the code from the console to run in a Canvas or window 
public class Game extends Canvas implements Runnable {
	
	private static final long serialVersionUID = -8255319694373975038L;
	
	static Scanner input = new Scanner (System.in);
	
	public static final int WIDTH = 800, HEIGHT = WIDTH / 15 * 12;
	
	// Creates the game thread which is the main source of the game 
	static Thread thread;
	private boolean running = false; //True or false function to determine whether the game is running or stopped
	
	private Random r;
	private Handler handler;
	private HUD hud;
	private Spawn spawner;
	static boolean runGame = false;
	
public Game() {
			
		handler = new Handler();
		
		r = new Random();
		
		this.addKeyListener(new KeyInput(handler));
		
		
		new Window(WIDTH, HEIGHT, "Snake Game", this);
		
		hud = new HUD();
		
		spawner = new Spawn(handler, hud);
		
		handler.addObject(new Player (WIDTH/2-32, HEIGHT/2-32, ID.Player, handler));
		handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.SmartEnemy, handler));
		//handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.BasicEnemy, handler));
}
	//Initiates the start of the game and starts the game thread
	public synchronized void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	// Initiates the end of the game and game thread stops and prints any errors in the console
	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	public void run() {
		//Game loop that converts real time to game time methods to create a constant and controlled speed for how the game operates
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountofTicks = 60.0;
		double ns = 1000000000 / amountofTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		while (running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while (delta >= 1) {
				tick();
				delta--;
			}
			
			if (running) 
				render();
				frames++;
				
			if (System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				//System.out.println("FPS: " + frames);
				frames = 0;
				}
			timer += delta;
		    if (frames <= 300) {
		    	frames = 80;
		    }
		}
		
		stop();
	}
	
	private void tick() {
		handler.tick();
			hud.tick();
			spawner.tick();
	}
	
	private void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null) {
			this.createBufferStrategy(4);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		handler.render(g);
			hud.render(g);
		
		
		g.dispose();
		bs.show();
	}
	
	public static float clamp(float var, float min, float max) {
		if (var >= max)
			return var = max;
		else if (var <= min)
			return var = min;
		else 
			return var;
		
	}

	public static void main (String[] args) {
		new Game();
	}
	

}

	

