package game_package;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Apples extends GameObject {
	
	private Handler handler;

	public Apples(float x, float y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;

	}

	public void tick() {
		
	}

	public void render(Graphics g) {
		g.setColor(Color.red);
		g.fillRect((int) x, (int) y, 16, 16);
		
		if (Game.runGame == false) {
			handler.removeObject(this);
		}
		
		if (HUD.score == 4000) {
			handler.removeObject(this);
		}
		
		if (HUD.HEALTH == 0) {
			handler.removeObject(this);
		}
	}

	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 16, 16);
	}	
}
