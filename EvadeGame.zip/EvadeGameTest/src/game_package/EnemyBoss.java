package game_package;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class EnemyBoss extends GameObject {
	
	private Handler handler;
	Random r = new Random();
	
	private int timer = 70;
	private int timer2 = 50;
	private int timer3 = 50;
	private int fastenemytimer = 400;
	private int smartenemytimer = 100;
	private int basicenemyloop = 0;
	private int fastenemyloop = 0;
	private int smartenemyloop = 0;
	
	public EnemyBoss(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		
		this.handler = handler;
		
		velX = 0;
		velY = 2;
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 96, 96);
	}

	public void tick() {
		x += velX;
		y += velY;
		
		if (fastenemytimer <= 0) {
					handler.addObject(new FastBullets (r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.FastEnemy, handler));
					fastenemytimer = 400;
					fastenemyloop = fastenemyloop + 1;
		}
		else {
			fastenemytimer--;
		}
		if (fastenemyloop == 3) {
			fastenemytimer = 400;
			fastenemytimer++;
		}

		
		if (timer <= 0) {
			velY = 0;
		}
		else {
			timer--;
		}
		
		if (timer == 0) timer2--;
			if (timer2 <= 0) {
				if (velX == 0) velX = 3;
					smartenemytimer--;
					if (smartenemytimer == 0) {
						handler.addObject(new Bullets ((int) x, (int) y, ID.SmartEnemy, handler));
						smartenemytimer = 300;
						smartenemyloop = smartenemyloop + 1;
					}
					else if (smartenemyloop == 2) {
						smartenemytimer = 300;
						smartenemytimer++;
					}
			}
		
		
		if (x <= 0 || x >= Game.WIDTH - 96) {
			velX *= -1;
		}
		
		timer3--;
		if (timer3 == 0) {
				handler.addObject(new BasicBullets ((int) x, (int) y, ID.BasicEnemy, handler));
				timer3 = 200;
				basicenemyloop = basicenemyloop + 1;
			}
		else if (basicenemyloop == 3) {
			timer3 = 50;
			timer3++;
		}
	}

	public void render(Graphics g) {
		g.setColor(Color.blue);
		g.fillRect((int) x, (int) y, 96, 96);
		
		if (Game.runGame == false) {
			handler.removeObject(this);
		}
		
		if (HUD.score == 4000) {
			handler.removeObject(this);
		}
		
		if (HUD.HEALTH == 0) {
			handler.removeObject(this);
		}
	}

}


