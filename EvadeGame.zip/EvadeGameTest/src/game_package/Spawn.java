package game_package;

import java.util.Random;

public class Spawn {

	private Handler handler;
	private HUD hud;
	private Random r = new Random();
	
	private static int scoreKeep = 0;
	
	public Spawn(Handler handler, HUD hud) {
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick() {
		
	if (HUD.score == 4000 || scoreKeep == 4000) {
		hud.setLevel(20 - 1);
	}
		
	if (Game.runGame == false) {
		handler.clearEnemies();
		HUD.score = 0;
		HUD.level = 0;
	}
	
	else if (Game.runGame == true) {
		HUD.level = HUD.getLevel();	
		
		if (HUD.score < 4000) {
			scoreKeep++;
		}
			else if (HUD.score == 4000) {
				scoreKeep = 4000;
				if (HUD.getLevel() == 20) {
					HUD.level = 20;
				}
				
			}
			
			if (scoreKeep >= 200) {
				scoreKeep = 0;
				hud.setLevel(HUD.getLevel() + 1);
				
				if (HUD.score <= 200) {
					handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.BasicEnemy, handler));
				}
				
				if (HUD.getLevel() == 2) {
					handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.BasicEnemy, handler));
					handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.BasicEnemy, handler));
				}
				else if (HUD.getLevel() == 3) {
					handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.BasicEnemy, handler));
					
				}
				else if (HUD.getLevel() == 4) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.FastEnemy, handler));
					handler.addObject(new Apples(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.Apples, handler));
					handler.addObject(new Apples(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.Apples, handler));
				}
				else if (HUD.getLevel() == 5) {
					handler.addObject(new SmartEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.SmartEnemy, handler));
				}
				else if (HUD.getLevel() == 6) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.FastEnemy, handler));
						handler.addObject(new Apples(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.Apples, handler));
				}
				else if (HUD.getLevel() == 7) {
					handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.FastEnemy, handler));
				}
				else if (HUD.getLevel() == 10) {
					handler.clearEnemies();
					handler.addObject(new EnemyBoss((Game.WIDTH / 2 - 64), -90, ID.EnemyBoss, handler));
					for (int i = 0; i < 3; i++) {
						handler.addObject(new Apples(r.nextInt(Game.WIDTH - 32), r.nextInt(Game.HEIGHT - 46), ID.Apples, handler));
					}
					
				}
				
				if (HUD.HEALTH == 0) {
					handler.clearEnemies();
					scoreKeep = 0;
					HUD.score = 0;
					HUD.level = 0;
				}	
			}
		}
	}	
}

