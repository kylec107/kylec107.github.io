package game_package;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class HUD {
	
	public static float HEALTH = 100;
	
	public static int score = 0;
	static int level = 1;

	public void tick() {
		HEALTH = Game.clamp(HEALTH, 0, 100);
		
		if (HEALTH == 0) {
			score = 0;
			level = 0;
		}
		
		else if (score < 4000) {
		score++;
	}
		else if (score == 4000) {
			score = 4000;
		}
}
	

	
	public void render(Graphics g) {
		
		if (Game.runGame == false) {
			Font fnt1 = new Font ("arial", 1, 50);
			g.setFont(fnt1);
			g.setColor(Color.red);
			g.drawString("EVADE", Game.HEIGHT / 2 - 10 , 150);
			
			Font fnt = new Font ("arial", 1, 20);
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("by Kyle Chandrasena", Game.HEIGHT / 2 - 22 , 180);
			
			Font fnt3 = new Font ("arial", 1, 20);
			g.setFont(fnt3);
			g.setColor(Color.green);
			g.drawString("ENTER", Game.HEIGHT / 2 - 1, 430);
			
			Font fnt4 = new Font ("arial", 1, 20);
			g.setFont(fnt4);
			g.setColor(Color.red);
			g.drawString("ESC", Game.HEIGHT / 2 + 14, 500);
			
			Font fnt2 = new Font ("arial", 1, 20);
			g.setFont(fnt2);
			g.setColor(Color.white);
			g.drawString("Use the WASD keys to control the player and avoid enemies", Game.HEIGHT / 2 - 210, 250);
			g.drawString("Avoid various types of enemies and consume red apples to regain health", Game.HEIGHT / 2 - 270, 350);
			g.drawString("Press the              key to play the game", Game.HEIGHT / 2 - 100, 430);
			g.drawString("Press the          key to quit the game", Game.HEIGHT / 2 - 85, 500);
		}
		
		else if (Game.runGame == true) {
			
			g.setColor(Color.gray);
			g.fillRect(15, 15, 200, 32);
			g.setColor(Color.green);
			g.fillRect( 15, 15, (int) HEALTH * 2, 32);
			g.setColor(Color.white);
			g.drawRect(15, 15, 200, 32);
			
			if (HEALTH == 0) {
				getScore();
				getLevel();
			}
			
			
			g.drawString("Score: " + score, 15, 64);
			g.drawString("Level: " + level, 15, 80);
			
			if (score == 4000) {
				score = 4000;
				Font fnt = new Font("arial", 1, 30);
				g.setFont(fnt);
				g.setColor(Color.white);
				g.drawString("Congratulations you have won!!", Game.WIDTH / 2 - 230, Game.HEIGHT / 2);
			}
			
			if (score == 0) {
				score = 0;
				Font fnt = new Font("arial", 1, 30);
				g.setFont(fnt);
				g.setColor(Color.white);
				g.drawString("You have failed to evade the enemies, try again", Game.WIDTH / 2 - 350, Game.HEIGHT / 2);
			}
		}
	}
	
	public void score(int score) {
		HUD.score = score;
	}
	
	public static int getScore() {
		return HUD.score;
	}
	
	public static int getLevel() {
		return HUD.level;
	}
	
	public void setLevel(int level) {
		HUD.level = level;
	}
	
}

